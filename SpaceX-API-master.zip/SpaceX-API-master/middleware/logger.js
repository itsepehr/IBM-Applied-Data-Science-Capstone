import pino from 'pino';

export default pino();
